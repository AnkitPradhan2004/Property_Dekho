const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const Property = require('../models/Property');
require('dotenv').config();

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/property-dekho');
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Property.deleteMany({});
    console.log('Cleared existing data');

    // Create sample users
    const hashedPassword = await bcrypt.hash('password123', 12);
    
    const users = await User.create([
      {
        name: 'John Doe',
        email: 'john@example.com',
        password: hashedPassword,
        role: 'user'
      },
      {
        name: 'Jane Smith',
        email: 'jane@example.com',
        password: hashedPassword,
        role: 'user'
      },
      {
        name: 'Admin User',
        email: 'admin@example.com',
        password: hashedPassword,
        role: 'admin'
      }
    ]);

    console.log('Created sample users');

    // Sample property images (using placeholder URLs)
    const sampleImages = [
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1605146769289-440113cc3d00?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=800&h=600&fit=crop'
    ];

    // Create sample properties
    const properties = await Property.create([
      {
        title: 'Modern Downtown Apartment',
        description: 'Beautiful modern apartment in the heart of downtown with stunning city views.',
        price: 450000,
        type: 'apartment',
        location: {
          address: '123 Main St',
          city: 'New York',
          region: 'NY',
          zip: '10001',
          coordinates: [-74.006, 40.7128]
        },
        amenities: ['Pool', 'Gym', 'Parking', 'Balcony'],
        bedrooms: 2,
        bathrooms: 2,
        squareFootage: 1200,
        images: [sampleImages[0], sampleImages[1]],
        agent: users[0]._id
      },
      {
        title: 'Spacious Family House',
        description: 'Perfect family home with large backyard and modern amenities.',
        price: 650000,
        type: 'house',
        location: {
          address: '456 Oak Ave',
          city: 'Los Angeles',
          region: 'CA',
          zip: '90210',
          coordinates: [-118.2437, 34.0522]
        },
        amenities: ['Garden', 'Garage', 'Fireplace', 'Patio'],
        bedrooms: 4,
        bathrooms: 3,
        squareFootage: 2500,
        images: [sampleImages[2], sampleImages[3]],
        agent: users[1]._id
      },
      {
        title: 'Luxury Penthouse',
        description: 'Exclusive penthouse with panoramic views and premium finishes.',
        price: 1200000,
        type: 'apartment',
        location: {
          address: '789 Park Ave',
          city: 'Miami',
          region: 'FL',
          zip: '33101',
          coordinates: [-80.1918, 25.7617]
        },
        amenities: ['Pool', 'Concierge', 'Gym', 'Terrace', 'Elevator'],
        bedrooms: 3,
        bathrooms: 3,
        squareFootage: 2000,
        images: [sampleImages[4], sampleImages[0]],
        agent: users[0]._id
      },
      {
        title: 'Cozy Studio Apartment',
        description: 'Perfect starter home in a quiet neighborhood with easy access to public transport.',
        price: 280000,
        type: 'apartment',
        location: {
          address: '321 Elm St',
          city: 'Chicago',
          region: 'IL',
          zip: '60601',
          coordinates: [-87.6298, 41.8781]
        },
        amenities: ['Parking', 'Laundry'],
        bedrooms: 1,
        bathrooms: 1,
        squareFootage: 600,
        images: [sampleImages[1], sampleImages[2]],
        agent: users[1]._id
      },
      {
        title: 'Executive Office Space',
        description: 'Premium office space in business district with modern facilities.',
        price: 850000,
        type: 'office',
        location: {
          address: '555 Business Blvd',
          city: 'San Francisco',
          region: 'CA',
          zip: '94105',
          coordinates: [-122.4194, 37.7749]
        },
        amenities: ['Parking', 'Security', 'Conference Room', 'Reception'],
        bedrooms: 0,
        bathrooms: 2,
        squareFootage: 1800,
        images: [sampleImages[3], sampleImages[4]],
        agent: users[2]._id
      }
    ]);

    console.log('Created sample properties');

    // Add some favorites and comparisons
    users[0].favorites = [properties[0]._id, properties[2]._id];
    users[0].comparisons = [properties[0]._id, properties[1]._id];
    await users[0].save();

    users[1].favorites = [properties[1]._id, properties[3]._id];
    users[1].comparisons = [properties[2]._id, properties[3]._id];
    await users[1].save();

    console.log('Added sample favorites and comparisons');
    console.log('Seed data created successfully!');
    console.log('\nSample credentials:');
    console.log('User: john@example.com / password123');
    console.log('User: jane@example.com / password123');
    console.log('Admin: admin@example.com / password123');

    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
};

seedData();