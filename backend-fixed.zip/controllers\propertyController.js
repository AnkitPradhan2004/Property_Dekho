const Property = require("../models/Property");

// GET /properties (with filters)
exports.getProperties = async (req, res) => {
  try {
    const {
      type,
      minPrice,
      maxPrice,
      city,
      bedrooms,
      amenities,
      sortBy,
      sortOrder,
      page,
      limit,
      lat,
      lng,
      radius
    } = req.query;

    let filters = {};

    // Type filter
    if (type) filters.type = type;

    // Location filter
    if (city) filters["location.city"] = city;

    // Price filter
    if (minPrice || maxPrice) {
      filters.price = {};
      if (minPrice) filters.price.$gte = Number(minPrice);
      if (maxPrice) filters.price.$lte = Number(maxPrice);
    }

    // Bedrooms filter
    if (bedrooms) filters.bedrooms = { $gte: Number(bedrooms) };

    // Amenities filter (comma separated) - sanitize input
    if (amenities) {
      const sanitizedAmenities = amenities.split(",").map(a => a.trim()).filter(a => a.length > 0);
      if (sanitizedAmenities.length > 0) {
        filters.amenities = { $all: sanitizedAmenities };
      }
    }

    // Geo-radius filter (requires property.location.coordinates with [lng,lat])
    if (lat && lng && radius) {
      filters["location.coordinates"] = {
        $geoWithin: {
          $centerSphere: [[parseFloat(lng), parseFloat(lat)], radius / 6378.1] // radius in km
        }
      };
    }

    // Pagination
    const pageNum = parseInt(page) || 1;
    const limitNum = parseInt(limit) || 10;
    const skip = (pageNum - 1) * limitNum;

    // Sorting
    let sort = {};
    if (sortBy) {
      sort[sortBy] = sortOrder === "desc" ? -1 : 1;
    } else {
      sort.createdAt = -1; // default newest first
    }

    const total = await Property.countDocuments(filters);
    const properties = await Property.find(filters)
      .populate("agent", "name email")
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    res.json({
      total,
      page: pageNum,
      pages: Math.ceil(total / limitNum),
      properties
    });
  } catch (err) {
    console.error('Get properties error:', err.message);
    res.status(500).json({ message: "Server error" });
  }
};

// GET /properties/:id
exports.getPropertyById = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id).populate("agent", "name email phone");
    if (!property) return res.status(404).json({ message: "Property not found" });
    res.json(property);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// POST /properties (Admin/Agent only)
exports.createProperty = async (req, res) => {
  try {
    // Parse JSON fields if they come as strings (from FormData)
    const parseField = (field) => {
      if (typeof field === 'string') {
        try {
          return JSON.parse(field);
        } catch {
          return field;
        }
      }
      return field;
    };

    // Validate and sanitize input data
    const allowedFields = ['title', 'description', 'type', 'price', 'location', 'bedrooms', 'bathrooms', 'squareFootage', 'amenities', 'images'];
    const propertyData = {};
    
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        propertyData[field] = parseField(req.body[field]);
      }
    });
    
    // Ensure required fields
    if (!propertyData.title || !propertyData.price || !propertyData.type) {
      return res.status(400).json({ message: 'Title, price, and type are required' });
    }
    
    propertyData.agent = req.user._id;
    const property = await Property.create(propertyData);
    res.status(201).json(property);
  } catch (err) {
    console.error('Create property error:', err.message);
    res.status(400).json({ message: "Invalid data" });
  }
};

// PUT /properties/:id
exports.updateProperty = async (req, res) => {
  try {
    // Parse JSON fields if they come as strings (from FormData)
    const parseField = (field) => {
      if (typeof field === 'string') {
        try {
          return JSON.parse(field);
        } catch {
          return field;
        }
      }
      return field;
    };

    // Validate and sanitize input data
    const allowedFields = ['title', 'description', 'type', 'price', 'location', 'bedrooms', 'bathrooms', 'squareFootage', 'amenities', 'images'];
    const updateData = {};
    
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        updateData[field] = parseField(req.body[field]);
      }
    });
    
    const property = await Property.findByIdAndUpdate(req.params.id, updateData, { new: true, runValidators: true });
    if (!property) return res.status(404).json({ message: "Property not found" });
    res.json(property);
  } catch (err) {
    console.error('Update property error:', err.message);
    res.status(400).json({ message: "Invalid data" });
  }
};

// DELETE /properties/:id
exports.deleteProperty = async (req, res) => {
  try {
    const property = await Property.findByIdAndDelete(req.params.id);
    if (!property) return res.status(404).json({ message: "Property not found" });
    res.json({ message: "Property deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

